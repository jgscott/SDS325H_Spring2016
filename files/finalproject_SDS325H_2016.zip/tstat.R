# This function returns the vector of t-statistics
# for the linear model object you supply it
# Copy/paste this function to the console and
# it will become available for use
tstat = function(mylm) {
	return(coef(mylm)/sqrt(diag(vcov(mylm))))
}

# Example usage

# Simulate data
x = runif(100, 0, 10)
y = 3 - 1.2*x + rnorm(100, 0, 3)
plot(y ~ x)

# Fit the model and extract the t statistics
lm1 = lm(y ~ x)
tstat(lm1)
tstat(lm1)[2]
